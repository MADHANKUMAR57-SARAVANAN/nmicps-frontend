export class Login{
    constructor(public email:any,public password:any){}
}