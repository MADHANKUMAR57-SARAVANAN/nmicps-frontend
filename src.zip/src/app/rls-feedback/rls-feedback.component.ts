import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contact-grid',
  templateUrl: './rls-feedback.component.html',
  styleUrls: ['./rls-feedback.component.scss']
})
export class RLSFeedbackComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
